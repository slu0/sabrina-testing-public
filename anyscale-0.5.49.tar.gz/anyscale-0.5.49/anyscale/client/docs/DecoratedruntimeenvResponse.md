# DecoratedruntimeenvResponse

A response from the API. Contains a field \"result\" which has the contents of the response.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | [**DecoratedRuntimeEnv**](DecoratedRuntimeEnv.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


