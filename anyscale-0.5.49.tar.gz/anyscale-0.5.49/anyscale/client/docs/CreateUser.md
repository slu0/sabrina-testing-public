# CreateUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**username** | **str** |  | 
**email** | **str** |  | 
**password** | **str** |  | 
**invite_code** | **str** |  | [optional] 
**organization_name** | **str** |  | [optional] 
**invitation_id** | **str** |  | [optional] 
**lastname** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


