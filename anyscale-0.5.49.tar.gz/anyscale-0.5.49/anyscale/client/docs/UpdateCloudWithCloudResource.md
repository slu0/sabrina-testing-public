# UpdateCloudWithCloudResource

Updatable fields for a CloudWithCloudResource. If a field is absent, it will not be updated.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**availability_zones** | **list[str]** | The availability zones that instances of this cloud are allowed to be launched in. | [optional] 
**state** | [**CloudState**](CloudState.md) | The state of this cloud. | [optional] 
**cloud_resource_to_update** | [**CreateCloudResource**](CreateCloudResource.md) | The cloud resource of this cloud. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


