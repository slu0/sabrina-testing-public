# CreateBYODBuild

Model used to create a BYOD Build.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_template_id** | **str** | ID of the App Config this Build belongs to. | 
**config_json** | [**CreateBYODAppConfigConfigurationSchema**](CreateBYODAppConfigConfigurationSchema.md) | Config JSON to use to create a new BYOD Build. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


