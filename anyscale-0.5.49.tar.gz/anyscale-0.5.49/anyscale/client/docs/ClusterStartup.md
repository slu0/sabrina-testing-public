# ClusterStartup

A cluster startup.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_time** | **datetime** | When the startup was initiated. Should be timezone-aware. | 
**cluster_id** | **str** | Cluster ID from sessions table. None if not known yet. | [optional] 
**id** | **str** | Unique identifier for this startup. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


