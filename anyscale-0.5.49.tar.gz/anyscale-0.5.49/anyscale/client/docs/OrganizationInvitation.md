# OrganizationInvitation

Organization Invitation model returned to clients in read APIs
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** |  | 
**id** | **str** |  | 
**organization_id** | **str** |  | 
**accepted_at** | **datetime** |  | [optional] 
**created_at** | **datetime** |  | 
**expires_at** | **datetime** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


