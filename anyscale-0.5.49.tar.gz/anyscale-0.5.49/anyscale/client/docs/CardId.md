# CardId

Lists all valid card ids. Card ids should not be removed from here to ensure a future card does not get created with a previously used id. Adding new card ids to this list will be considered a backwards incompatible change by CI, so those changes will need to be force merged.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


