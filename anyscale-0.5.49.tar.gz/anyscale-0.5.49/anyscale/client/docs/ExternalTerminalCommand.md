# ExternalTerminalCommand

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scid** | **str** |  | 
**command** | **str** |  | 
**created_at** | **datetime** |  | 
**finished_at** | **datetime** |  | [optional] 
**status_code** | **int** |  | [optional] 
**type** | [**SessionCommandTypes**](SessionCommandTypes.md) |  | 
**web_terminal_tab_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


