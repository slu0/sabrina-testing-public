# LogDetails

A collection of LogDetail.     
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**log_files** | [**list[LogDetail]**](LogDetail.md) | collection of LogDetail. | 
**next_page_token** | **str** | next page token, default None. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


