# CreateCloudResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aws_vpc_id** | **str** | The AWS vpc id of this cloud. | [optional] 
**aws_subnet_ids** | **list[str]** | A list of AWS subnet IDs of this cloud. | [optional] 
**aws_iam_role_arns** | **list[str]** | A list of AWS IAM role arns of this cloud. | [optional] 
**aws_security_groups** | **list[str]** | A list of AWS security groups of this cloud. | [optional] 
**aws_s3_id** | **str** | The AWS S3 id of this cloud. | [optional] 
**aws_efs_id** | **str** | The AWS EFS id of this cloud. | [optional] 
**aws_cloudformation_stack_id** | **str** | The AWS CloudFormation stack id of this cloud. | [optional] 
**gcp_vpc_id** | **str** | The GCP vpc id of this cloud. | [optional] 
**gcp_subnet_ids** | **list[str]** | A list of GCP subnet IDs of this cloud. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


